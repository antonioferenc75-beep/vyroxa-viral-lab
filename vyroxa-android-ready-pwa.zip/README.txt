# Vyroxa Video App — PWA balíček

## Co obsahuje
- `index.html` — aplikace
- `manifest.webmanifest` — údaje pro instalaci jako webovou aplikaci
- `sw.js` — základní service worker pro shell aplikace
- `icon.svg` — ikona

## Zveřejnění zdarma
1. Nahraj všechny čtyři soubory do kořene veřejného GitHub repozitáře.
2. Zapni GitHub Pages pro větev `main` a složku `/(root)`.
3. Po zveřejnění otevři HTTPS adresu aplikace a vlož ji do PWABuilderu.
4. V PWABuilderu zvol Android a vytvoř balíček. Pro instalaci mimo Google Play použij vhodný APK výstup a ověř jeho podpis.

Poznámka: video ukázky jsou načítané z externích URL. Service worker ukládá jen základní soubory aplikace; nezaručuje offline přehrávání videí. Nahrávání videa v tomto prototypu je pouze místní náhled, ne veřejné publikování.
